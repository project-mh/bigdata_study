


# *************** 데이터의 대략적인 특징 파악 *************** #
# head() 함수
# head(데이터, 추출할 행 개수)
# 인자가 없으면 첫번째 행부터 6번째 행까지 추출함

# tail() 함수
# tail(데이터, 추출할 행 개수)
# 인자가 없으면 마지막 행부터 6개 행을 추출함 

# str() 함수
# 데이터의 대략적인 구조를 파악

# summary() 함수
# 수치형 데이터의 경우 
# 각 컬럼별로 최소값, 1사분위수, 중앙값, 3사분위수, 최대값, 평균을 구할 수 있음
# 범주형 데이터의 경우
# 관측치 개수를 구할 수 있음

# head() 함수 예제
head(Orange)    # 첫번째 행부터 6번째 행까지 추출                          
head(Orange,3)  # 첫번째 행부터 3번째 행까지 추출 

# tail() 함수 예제
tail(Orange)    # 마지막 행부터 6개의 행까지 추출
tail(Orange,10) # 마지막 행부터 3개의 행까지 추출 

# str() 함수 예제
str(Orange)     #데이터의 구조를 파악 

# summary() 함수 예제제
summary  (Orange)
 
# ************************** ***** ************************** #



# ********************* 외부 파일 읽기1 ********************** #
# CSV 파일 불러오기
# read.csv()로 csv파일 불러올 수 있음
# 첫번째 행에 열 이름이 없이 데이터부터 존재하면 header=F 옵션을 지정
# 문자열 데이터를 범주형 데이터로 읽기를 원하면 stringAsFactor=TRUE 옵션을 지정

# 디렉토리에서 파일의 존재를 확인했는데 에러가 발생한다면 인코딩 문제일 가능성
# fileEncoding옵션으로 인코딩 지정해주면 됨
# fileEncoding="EUC-KR"
# fileEncoding="UTF-8"  과 같이 사용함

# csv파일 불러오기
nhis <- read.csv("./data/NHIS_OPEN_GJ_EUC-KR.csv")
head(nhis) 

nhis <- read.csv("./data/NHIS_OPEN_GJ_EUC-KR.csv", fileEncoding="EUC-KR")
nhis <- read.csv("./data/NHIS_OPEN_GJ_UTF-8.csv", fileEncoding = "UTF-8" ) 

sample<- read.csv("./data/sample.csv", 
                  header = FALSE,
                  fileEncoding="EUC-KR", 
                  stringsAsFactor = TRUE) 
str(sample)

# ************************** ****** ************************** #



# ********************* 외부 파일 읽기2 ********************** #
# 엑셀 파일 불러오기
# 엑셀 파일을 읽으려면 패키지를 설치해야 함
# 엑셀파일을 다루는 여러가지 패키지 중 openxlsx 패키지의 read.xlsx() 사용

#엑셀 파일 불러오기
install.packages('openxlsx') # openxlsx 패키지 설치    
library(openxlsx)            # openxlsx 패키지 읽어옴

nhis_sheet1= read.xlsx('./data/NHIS_OPEN_GJ_EUC-KR.xlsx') # 디폴트로 엑셀 파일의 첫번째 sheet를 읽음.
nhis_sheet2= read.xlsx('./data/NHIS_OPEN_GJ_EUC-KR.xlsx', sheet=2) # 엑셀 파일의 두번째 sheet를 읽음.

# ************************** ****** ************************** #  



# ********************* 외부 파일 읽기3 ********************** #
# 빅데이터 파일 불러오기
# data.table 패키지의 fread() 함수
# 빠른 속도로 데이터를 읽어올 수 있어, 빅데이터 파일을 읽을 때 유용함

# 빅데이터 파일 불러오기
install.packages('data.table') # data.table 패키지 설치    
library(data.table)            # data.table 패키지 불러오기 

nhis_bigdata = fread("./data/NHIS_OPEN_GJ_BIGDATA_UTF-8.csv", encoding = "UTF-8" )
str(nhis_bigdata) # 읽어온 데이터 구조 파악

# ************************** ****** ************************** #



# *********************** 데이터 추출 *********************** #
# 데이터 추출 
# 행제한
# 1) 행 인덱스를 이용해서 행을 제한할 수 있음
# 2) 데이터를 비교하여 행을 제한함
#    대괄호 안에서 데이터를 비교하여 추출할 행을 제한

# 열제한
# 1) 열 인덱스를 이용해서 열을 제한할 수 있음
# 2) 열 이름을 이용해서 열을 제한할 수 있음
#    추출할 열 이름을 대괄호 안 콤마 뒤에 작성하면 됨

# 행과 열제한
# 데이터프레임의 대괄호 안에 행 인덱스나 비교 연산자를 이용해서 행을 제한하고
# 콤마 뒤 추출할 열 이름이나 열 인덱스를 작성

# 행 인덱스를 이용하여 행 제한
Orange[1, ]           # 1행만 추출 
Orange[1:5, ]         # 1행부터 5행까지 추출
Orange[6:10, ]        # 6행부터 10행까지 추출
Orange[c(1,5), ]      # 1행과 5행 추출
Orange[-c(1:29), ]    # 1~29행  제외하고 모든 행 추출  

# 데이터를 비교하여 행 제한
Orange[Orange$age == 118, ]          # age 컬럼 데이터가 118인 행만 추출
Orange[Orange$age %in% c(118,484), ] # age 컬럼 데이터가 118 또는 484인 행만 추출
Orange[Orange$age >= 1372 , ]        # age 컬럼 데이터가 1372와 같거나 큰 행만 추출 

# 열이름을 이용하여 열 제한  
Orange[ 1 , c("Tree","circumference")] # Orange의 Tree와 circumference열만 추출. 행은 1행만 추출 
Orange[ , "circumference"]             # Orange의 circumference 열만 추출. 행은 모든 행 추출

Orange[ , 1]       # Orange 데이터프레임의 첫번째 열만 추출
Orange[ , c(1,3)]  # Orange 데이터프레임의 1열과 3열만 추출
Orange[ , c(1:3)]  # Orange 데이터프레임의 첫번째 열부터 3번째 열까지 추출 
Orange[ , -c(1,3)] # Orange 데이터프레임의 1열과 3열만 제외하고 추출

#행과 열제한 
Orange[1:5 , "circumference"] 
Orange[Orange$Tree %in% c(3,2)
       , c("Tree","circumference")] # Tree열이 3또는 2인 행의 Tree 열과 circumference 열 추출 

# ************************** ***** ************************** #



# ************************** 정렬 ************************** #
# 정렬
# order() 함수
# 데이터프레임의 값을 정렬함

# 데이터프레임의 그룹별 집계
# aggregate() 함수
# aggregate(그룹핑할 기준 열이름 ~ 집계할 데이터가 있는 열 이름름)

OrangeT1 <- Orange[Orange$circumference < 50, ] 
OrangeT1[ order(OrangeT1$circumference), ]

# 내림차순 정렬은 order()안에 마이너스(-) 기호를 사용하면 됨 
OrangeT1[ order( -OrangeT1$circumference ),  ]  

# 그룹별 집계   
# Tree 별 circumference 평균
aggregate(circumference ~ Tree, Orange, mean)
  
# ************************** **** ************************** #


# ******************* 데이터 구조 변경 ******************* #
# 데이터 구조 변경

# 데이터 병합
# merge(), rbind(), cbind()
# 열방향으로 두 데이터프레임을 병합할 때 사용하는 함수

# merge() 함수
# 병합대상 데이터프레임들의 동일 컬럼명의 동일 데이터 행끼리 병합함
# all=TRUE 옵션으로 동일 컬럼끼리 값이 일치하지 않는 행도 병합 결과에 포함시킬 수 있음
# SQL의 외부조인(full outer join)

# rbind() 함수
# 행을 합침 (두 데이터프레임의 컬럼명이 동일해야 함)

# cbind() 함수
# 컬럼을 합침

## 데이터 준비 
stu1 <- data.frame( no = c(1,2,3), midterm = c(100,90,80)) 
stu2 <- data.frame( no = c(1,2,3), finalterm = c(100,90,80)) 
stu3 <- data.frame( no = c(1,4,5), quiz = c(99,88,77)) 
stu4 <- data.frame( no = c(4,5,6), midterm = c(99,88,77))  

# 데이터 병합 - merge() 함수
stu1
stu2
merge(stu1, stu2)
stu3
merge(stu1, stu3)
merge(stu1, stu3, all=TRUE) 

# 데이터 병합 - rbind() 함수
stu4
stu1
rbind(stu1, stu4)

# 데이터 병합 - cbind() 함수
stu2
cbind(stu1, stu2)
cbind(stu1, stu3)

# ************************* **** ************************* #


