#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("Hello")


# In[2]:


print("Python")


# - bullet 기호 표시
# ---

# # 제목 크기
# ## 제목 크기
# ### 제목 크기
# #### 제목 크기
# ##### 제목 크기

# 1. 첫번째
# 1. 두번째
# 1. 세번째
# 
# - 첫번째
# - 두번째
# - 세번째
# ---
